import os
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

from files import read_urls_comment_by_main_account

def is_white_list_account(element, white_list):
    try:
        elements = element.find_elements(By.TAG_NAME, 'a')
        for tag_a in elements:
            print(tag_a.get_attribute("href"))
            for account in white_list:
                if tag_a.get_attribute("href").endswith(account):
                    return tag_a
    except:
        return None    
    return None

def is_white_account(element, white_list):
    try:
        any(tag.get_attribute("href").endswith(account) for account in white_list for tag in element.find_elements(By.TAG_NAME, 'a'))
    except:
        return False
#Test ok
def is_verify_yellow(element):
    try:
        return any(os.getenv("PATH_VERIFY_YELLOW") in tag.get_attribute("d") for tag in element.find_elements(By.TAG_NAME, 'path'))
    except:
        print('exception is_verify_yellow')
        return False
#Test ok
def is_verify_blue(element):
    try:
        return any(os.getenv("PATH_VERIFY_BLUE") in tag.get_attribute("d") for tag in element.find_elements(By.TAG_NAME, 'path'))
    except:
        print('exception is_verify_blue')
        return False
def is_advertisement(element):
    try:
        return any(os.getenv("PATH_ADVERTISEMENT") in tag.get_attribute("d") for tag in element.find_elements(By.TAG_NAME, 'path'))
    except:
        print('exception advertisement')
        return False
    

def is_video_tweet(element):
    try:
        video = element.find_element(By.CSS_SELECTOR, 'div[data-testid="videoPlayer"]')
        if video:
            return True
    except:
        return False
    return False


#New code
