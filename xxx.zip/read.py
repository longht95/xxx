def read_white_list_from_file(file_path):
    white_account = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                account = line.strip().split('|')[1]
                print(account)
                white_account.append(account)
    except FileNotFoundError:
        return white_account
    except Exception as e:
        return white_account
    return white_account

read_white_list_from_file('C:/Users/Long/Downloads/C9OAEBG3PE.txt')