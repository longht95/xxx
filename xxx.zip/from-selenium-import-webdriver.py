import json
import re
from selenium.webdriver.chrome.service import Service
import undetected_chromedriver as uc
import time
import os
import random
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium_stealth import stealth                                                                                        
from dotenv import load_dotenv
from AI import generate_content_by_text
from Checker import is_video_tweet, is_white_list_account
from actions import action_comment
from files import read_following_accounts_from_file, read_profile_list_from_file, read_urls_comment_by_main_account, read_white_account_from_file
import concurrent.futures
from finds import find_button_search, find_home_button, find_input_search

load_dotenv()

def scroll(driver, wait, action, profile):
    print('scroll')
    #New code
    white_accounts = read_white_account_from_file(os.getenv('PROFILE_PATH'))
    following_accounts = read_following_accounts_from_file(os.getenv("PROCESS_ACCOUNT_PATH")+profile.username+'.txt')
    urls_comment_by_main_account = read_urls_comment_by_main_account()
    main_accounts_not_yet_follow = [account for account in profile.accounts if account not in following_accounts]
    white_accounts_not_yet_follow = [account for account in white_accounts if account not in following_accounts]
    random.shuffle(white_accounts_not_yet_follow)

    element = valid_twwets_by_twwets(wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div[data-testid="cellInnerDiv"]'))))[0]
    #End code

    is_tab = is_tab_for_me(driver, wait)
    max_runtime = profile.time_process * 60
    follow_count = random.randint(5, 15)
    follow_runtime = follow_count * 60
    start_time = time.time()
    count_error = 0
    while True:
        current_time = time.time()
        elapsed_time = current_time - start_time
        url_current = find_url_tweet(element)
        print('url_current')
        print(url_current)
        if (elapsed_time >= follow_runtime and len(white_accounts_not_yet_follow) > 0):
            follow_count = follow_count + random.randint(5, 15)
            follow_runtime = follow_count * 60
            #search with account
            action_search_by_keyword(wait, action, white_accounts_not_yet_follow[0])
            time.sleep(random.uniform(2,10))
            elements = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div[data-testid="cellInnerDiv"]')))
            for element in elements:
                tag_a = is_white_list_account(element, [white_accounts_not_yet_follow[0]])
                if tag_a:
                    action_follow_in_profile(wait, tag_a, profile.username, action, white_accounts_not_yet_follow[0])
                    time.sleep(random.uniform(3, 10))
                    break
            button_home = find_home_button(wait)
            action.move_to_element(button_home).perform()
            time.sleep(random.uniform(0.5,2))
            action.click(button_home).perform()
            time.sleep(random.uniform(3, 10))
            white_accounts, following_accounts, urls_comment_by_main_account, main_accounts_not_yet_follow, white_accounts_not_yet_follow = refresh(profile.username,profile.accounts)
            #exception
            try:
                element = wait.until(lambda driver: waitNewElement(driver, url_current, False))
            except:
                element = wait.until(lambda driver: waitNewElement(driver, url_current, True))
        if elapsed_time >= max_runtime:
            print('stop')
            break
        
        is_tweet_find_main_account = len(main_accounts_not_yet_follow) > 0 and is_tweet_comment_by_main_account(element, urls_comment_by_main_account)

        if is_tweet_find_main_account:
            print('find main account')
            action_find_main_account(action, element, wait, profile.accounts, profile.username)
            white_accounts, following_accounts, urls_comment_by_main_account, main_accounts_not_yet_follow, white_accounts_not_yet_follow = refresh(profile.username,profile.accounts)
            element = wait.until(lambda driver: waitNewElement(driver, url_current, False))

        ################
        action.reset_actions()
        action.move_to_element(element).perform()
        isVideo = is_video_tweet(element)
        
        is_tweet_by_white_account = is_tweet_by_account(element, white_accounts)
        is_tweet_by_main_account = is_tweet_by_account(element, profile.accounts)
        



        #End code
        element_url_follow_account, user_follow_account = find_url_white_account(element, [*white_accounts_not_yet_follow, *main_accounts_not_yet_follow])


        if element_url_follow_account is not None and user_follow_account is not None:
            print('Follow natural')
            action_follow_in_profile(wait, element_url_follow_account, profile.username, action, user_follow_account)
            white_accounts, following_accounts, urls_comment_by_main_account, main_accounts_not_yet_follow, white_accounts_not_yet_follow = refresh(profile.username,profile.accounts)
            try:
                element = wait.until(lambda driver: waitNewElement(driver, url_current, False))
            except:
                element = wait.until(lambda driver: waitNewElement(driver, url_current, True))
        if isVideo == False: 
            #just like and comment in white accounts and main accounts (50% main)
            isLike = (random_boolean(profile.like_rate) and is_tweet_by_white_account) or (is_tweet_by_main_account and random_boolean(0.5))
            isComment = random_boolean(profile.comment_rate) and is_tweet_by_white_account or (is_tweet_by_main_account and random_boolean(0.5))
            time.sleep(random.uniform(5, 15))
            if (isLike):
                action_like(action, element)
            if (isComment):
                action_comment(element, action, driver, wait)
        try:
            element = wait.until(lambda driver: waitNewElement(driver, url_current, False))
        except:
            print('Exception need to checkkkkkkkkkkkkk')
            count_error += 1
            element = wait.until(lambda driver: waitNewElement(driver, url_current, True))
            if (count_error == 2):
                print('switch tab')
                navigation = driver.find_element(By.CSS_SELECTOR, 'nav[aria-live="polite"][role="navigation"]')
                tab_list = navigation.find_elements(By.TAG_NAME, 'a')
                if (is_tab):
                    action.move_to_element(tab_list[1]).perform()
                    time.sleep(1)
                    action.click().perform()
                    is_tab = False
                else:
                    action.move_to_element(tab_list[0]).perform()
                    time.sleep(1)
                    action.click().perform()
                    is_tab = True
                time.sleep(10)
                element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div[data-testid="cellInnerDiv"]')))
            if (count_error == 3):
                return
            
def process_profile(profile):
    chrome_options = uc.ChromeOptions()
    chrome_options.binary_location = os.getenv("BROWSER_PATH")
    width = random.uniform(350,400)
    height = random.uniform(900,1080)
    chrome_options.add_argument("--window-size="+str(width)+","+str(height))
    chrome_options.add_extension('C:/Users/Long/Downloads/xxx/1.0.14_0.zip')
    print('--proxy-server={}'.format(profile.proxy))
    if profile.proxy:
        chrome_options.add_argument('--proxy-server={}'.format(profile.proxy))
    print(profile.profile_dir)
    chrome_options.add_argument('--load-extension=C:/Users/Long/Downloads/xxx/1.0.14_0')
    service = Service(executable_path=os.getenv("DRIVER_PATH"))
    driver = uc.Chrome(service=service, options=chrome_options,version_main=119, user_multi_procs=True, user_data_dir=profile.profile_dir)
    
    stealth(driver,
        languages=["en-US", "en"],
        vendor="Google Inc.",
        platform="Win32",
        webgl_vendor="Intel Inc.",
        renderer="Intel Iris OpenGL Engine",
        fix_hairline=False,
        )
    wait = WebDriverWait(driver, 60)
    action = ActionChains(driver)
    driver.set_window_size(width, height)
    driver.execute_cdp_cmd('Network.setUserAgentOverride', {"userAgent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'})
    driver.get("https://twitter.com/")
    if driver.current_url != 'https://twitter.com/home':
        time.sleep(120)
    else:
        time.sleep(10)
    if profile.work:
        if profile.post:
            action_push_tweet(wait,action, profile.content_post)
        scroll(driver,wait,action, profile)
    else:
        time.sleep(100000)
    driver.quit()

def valid_twwets_by_twwets(twwets):
    valid_twwets = []
    for twwet in twwets:
        if find_url_tweet(twwet) is not None:
            valid_twwets.append(twwet)
    return valid_twwets

#automation
def waitNewElement(driver, url_current, lastIndex):
    twwets = driver.find_elements(By.CSS_SELECTOR, "div[data-testid='cellInnerDiv']")
    valid_twwets = valid_twwets_by_twwets(twwets)
    if len(valid_twwets) == 0:
        return False
    print('valid_twwets')
    print(len(valid_twwets))
    if (lastIndex or url_current is None):
        return valid_twwets[-1]
    next_index = find_index_element(url_current, valid_twwets)
    if (next_index != -1 and next_index != len(valid_twwets)):
        return valid_twwets[next_index]
    return False

def is_tab_for_me(driver, wait):
    navigation_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'nav[aria-live="polite"][role="navigation"]')))
    #navigation = driver.find_element(By.CSS_SELECTOR, 'div[aria-live="polite"][role="navigation"]')
    list_tab_element = navigation_element.find_element(By.TAG_NAME, 'a')
    print(list_tab_element.get_attribute('aria-selected'))
    if (list_tab_element.get_attribute('aria-selected') == 'true'):
        return True
    return False

####random########
def random_boolean(percent):
    return random.random() < percent


def action_search_by_keyword(wait, action, keyword):
    if keyword:
        action.reset_actions()
        button_search = find_button_search(wait)
        action.move_to_element(button_search).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click().perform()
        time.sleep(random.uniform(0.5,2))
        input_search = find_input_search(wait)
        action.move_to_element(input_search).perform()
        time.sleep(random.uniform(0.5,2))
        action.click(input_search).perform()
        time.sleep(random.uniform(0.5,2))
        action.send_keys(keyword).perform()
        time.sleep(random.uniform(0.5,2))
        action.send_keys(Keys.RETURN).perform()

def refresh(username, accounts):
    white_accounts = read_white_account_from_file(os.getenv('PROFILE_PATH'))
    following_accounts = read_following_accounts_from_file(os.getenv("PROCESS_ACCOUNT_PATH")+username+'.txt')
    urls_comment_by_main_account = read_urls_comment_by_main_account()
    main_accounts_not_yet_follow = [account for account in accounts if account not in following_accounts]
    white_accounts_not_yet_follow = [account for account in white_accounts if account not in following_accounts]
    return white_accounts, following_accounts, urls_comment_by_main_account, main_accounts_not_yet_follow, white_accounts_not_yet_follow



def action_push_tweet(wait, action, content):
    print('push tweet')
    input_tweet = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'div[contenteditable="true"][data-testid="tweetTextarea_0"][role="textbox"]')))
    content_text = generate_content_by_text(content)
    action.move_to_element(input_tweet).perform()
    time.sleep(random.uniform(0.5, 2))
    action.click(input_tweet).perform()
    contents = list(content_text)
    for c in contents:
        action.send_keys(c).perform()
        time.sleep(random.uniform(0.2, 1))
    action.send_keys(Keys.ENTER).perform()
    button_post = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'div[role="button"][data-testid="tweetButtonInline"]')))
    time.sleep(random.uniform(5,10))
    action.click(button_post).perform()
    action.reset_actions()

#NEW
def action_like(action, element):
    print('action_like')
    buttonLike = element.find_element(By.CSS_SELECTOR, 'div[role="button"][data-testid="like"]')
    if (buttonLike):
        action.move_to_element(buttonLike).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click().perform()
        action.reset_actions()
        time.sleep(random.uniform(2, 5))

def action_find_main_account(action, element, wait, accounts, username):
    print('find mainnnnnn')
    url_tweet = find_url_tweet_by_element(element)
    if (url_tweet):
        action.move_to_element(url_tweet).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click(url_tweet).perform()
        time.sleep(random.uniform(1, 10))
        elements = valid_twwets_by_twwets(wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div[data-testid="cellInnerDiv"]'))))
        while True:
            is_done = False
            for e in elements:
                account_main, account_follow = find_url_white_account(e, accounts)
                if (account_main is not None):
                    is_done = True
                    action_follow_in_profile(wait, account_main, username, action, account_follow)
                    break
            if is_done:
                break
            time.sleep(random.uniform(1, 5))
            action.reset_actions()
            try:
                action.scroll_by_amount(0, int(random.randint(300, 800))).perform()
                elements = valid_twwets_by_twwets(wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div[data-testid="cellInnerDiv"]'))))
            except:
                break
        button_home = find_home_button(wait)
        action.move_to_element(button_home).perform()
        time.sleep(random.uniform(0.5,2))
        action.click(button_home).perform() 
        

def action_follow_in_profile(wait, element, username, action, account_follow):
    print('follow')
    action.move_to_element(element).perform()
    time.sleep(random.uniform(0.5, 2))
    action.click(element).perform()
    action.reset_actions()
    time.sleep(random.uniform(3, 10))
    button_follow = find_button_follow_profile(wait)
    print('account_follow')
    print(account_follow)
    print('username')
    print(username)
    if button_follow:
        print('button_follow')
        print(button_follow)
        action.move_to_element(button_follow).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click(button_follow).perform()
        with open(os.getenv("PROCESS_ACCOUNT_PATH")+username+'.txt', 'a+') as file:
            file.write(account_follow+'\n')
    else:
        button_unfollow = find_button_unfollow_profile(wait)
        print('button_unfollow')
        print(button_unfollow)
        if button_unfollow:
            with open(os.getenv("PROCESS_ACCOUNT_PATH")+username+'.txt', 'a+') as file:
                file.write(account_follow+'\n')
    
    button_back = find_button_back(wait)
    action.move_to_element(button_back).perform()
    time.sleep(random.uniform(0.5, 2))
    action.click(button_back).perform()
#ok
def find_url_tweet_by_element(element):
    regex = r"https:\/\/twitter\.com\/\w+\/status\/\d+$"
    pattern = re.compile(regex)
    elements = element.find_elements(By.CSS_SELECTOR, 'a[href]')
    for e in elements:
        if pattern.match(e.get_attribute('href')):
            return e
    return None

def find_button_unfollow_profile(wait):
    try:
        script_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'script[type="application/ld+json"]')))
        data = json.loads(script_element.get_attribute('innerHTML'))
        identifier = data['author']['identifier']
        data_testid = '{}-unfollow'.format(identifier)
        button_follow = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'div[role="button"][data-testid="{}"]'.format(data_testid))))
        return button_follow
    except:
        return None

def find_button_follow_profile(wait):
    try:
        script_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'script[type="application/ld+json"]')))
        data = json.loads(script_element.get_attribute('innerHTML'))
        identifier = data['author']['identifier']
        data_testid = '{}-follow'.format(identifier)
        button_follow = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'div[role="button"][data-testid="{}"]'.format(data_testid))))
        return button_follow
    except:
        return None
#ok
def find_button_back(wait):
    svg_elements = wait.until(EC.presence_of_all_elements_located((By.TAG_NAME, 'path')))
    for svg_tag in svg_elements:
        if svg_tag.get_attribute("d") in [os.getenv("PATH_CLOSE_BUTTON"), os.getenv("PATH_BACK_BUTTON")]:
            return svg_tag
    return None
#ok
def find_url_white_account(element, accounts):
    try:
        elements = element.find_elements(By.CSS_SELECTOR, 'a[href]')
        for e in elements:
            for account in accounts:
                if e.get_attribute('href').endswith(account):
                    return e, account
    except:
        return None, None
    return None, None

def find_index_element(url_current, tweets):
    print(url_current)
    if url_current:
        for index, tweet in enumerate(tweets):
            tweet_link = find_url_tweet(tweet)
            if tweet_link and tweet_link == url_current:
                return index + 1
    return -1

def find_url_tweet(element):
    regex = r"https:\/\/twitter\.com\/\w+\/status\/\d+$"
    pattern = re.compile(regex)
    try:
        elements = element.find_elements(By.CSS_SELECTOR, 'a[href]')
        for e in elements:
            if pattern.match(e.get_attribute('href')):
                return e.get_attribute('href')
    except:
        return None
    return None

def is_tweet_by_account(element, accounts):
    elements = element.find_elements(By.CSS_SELECTOR, 'a[href]')
    for e in elements:
        for account in accounts:
            if e.get_attribute('href').endswith(account):
                return True
    return False

def is_tweet_comment_by_main_account(element, urls):
    elements = element.find_elements(By.CSS_SELECTOR, 'a[href]')
    for e in elements:
        for url in urls:
            if e.get_attribute('href') == url:
                return True
    return False

if __name__ == '__main__':
    max_threads = int(os.getenv("MAX_THREAD"))
    profiles = read_profile_list_from_file(os.getenv("PROFILE_PATH"))
    profiles_start = [profile for profile in profiles if profile.start]
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
        futures = [executor.submit(process_profile, profile) for profile in profiles_start]