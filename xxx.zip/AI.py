from io import BytesIO
import os
import PIL
import google.generativeai as genai
import requests

def generate_post():
    genai.configure(api_key=os.getenv("GENAI_API_KEY"))
    model = genai.GenerativeModel('gemini-pro')
    prompt = "Create a post based on the following criteria:\
    1. Generate a random post\
    2. Minimum 30 characters.\
    3. Maximum 280 characters.\
    4. Response only content\
    5. Response with the latest data information you have\
    6. Suitable topic for Twitter social network\
    7. Topics about life, work, personal, story, love, inspire\
    8. Do not use hashtags too much."
    return model.generate_content(prompt).text
def generate_comment_by_text(text):
    genai.configure(api_key=os.getenv("GENAI_API_KEY"))
    model = genai.GenerativeModel('gemini-pro')
    prompt = "Create a comment based on the following criteria:\
    1. Generate a random comment\
    2. Minimum 10 characters.\
    3. Maximum 100 characters.\
    4. Generate a comment based on the input enclosed in []\
    5. Response only content\
    [{}]".format(text)
    return model.generate_content(prompt).text

def generate_comment_by_image_and_text(text, images):
    genai.configure(api_key=os.getenv("GENAI_API_KEY"))
    model = genai.GenerativeModel(model_name="gemini-pro-vision")
    prompt = "Create a comment based on the following criteria:\
    1. Generate a random comment\
    2. Minimum 10 characters.\
    3. Maximum 100 characters.\
    4. Generate a comment based on a combination of string input enclosed in [] and images\
    5. Response only content\
    6. Response with the latest data information you have\
    [{}]".format(text)
    format = []
    format.append(prompt)
    for image in images:
      response = requests.get(image)
      cookie_picture = {
          'mime_type': response.headers.get('Content-Type'),
          'data': response.content
      }
      format.append(cookie_picture)
    return model.generate_content(format).text.lstrip()


def generate_content_by_text(text):
    genai.configure(api_key=os.getenv("GENAI_API_KEY"))
    generation_config = {
      "temperature": 0.9,
      "top_p": 1,
      "top_k": 1,
      "max_output_tokens": 100,
    }
    safety_settings = [
      {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      }
    ]
    model2 = genai.GenerativeModel(model_name="gemini-pro",generation_config=generation_config,safety_settings=safety_settings)
    return model2.generate_content(text).text

def generate_comment_by_text_images(input_tilte,url_images):
    genai.configure(api_key=os.getenv("GENAI_API_KEY"))
    generation_config = {
      "temperature": 0.9,
      "top_p": 1,
      "top_k": 1,
      "max_output_tokens": 100,
    }
    safety_settings = [
      {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      }
    ]
    model2 = genai.GenerativeModel(model_name="gemini-pro-vision",generation_config=generation_config,safety_settings=safety_settings)
    format = []
    #format_argument = "Generate a witty comment based on input text and images '"+input_tilte+"'"
    format.append('Generate a witty comment based on input text and images\n')
    for text in input_tilte:
        format.append('input text:' + text)
    
    for image in url_images:
      response = requests.get(image)
      img = PIL.Image.open(BytesIO(response.content))
      format.append(img)
    print(format)

    try:
        return model2.generate_content(format).text
    except:
        print('exception generate_content')
        return None
