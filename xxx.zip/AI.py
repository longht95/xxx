from io import BytesIO
import os
import PIL
import google.generativeai as genai
import requests

def generate_comment_by_text_images(input_tilte,url_images):
    genai.configure(api_key=os.getenv("GENAI_API_KEY"))
    generation_config = {
      "temperature": 0.9,
      "top_p": 1,
      "top_k": 1,
      "max_output_tokens": 100,
    }
    safety_settings = [
      {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
      }
    ]
    model2 = genai.GenerativeModel(model_name="gemini-pro-vision",generation_config=generation_config,safety_settings=safety_settings)
    format = []
    #format_argument = "Generate a witty comment based on input text and images '"+input_tilte+"'"
    format.append('Generate a witty comment based on input text and images\n')
    for text in input_tilte:
        format.append('input text:' + text)
    
    for image in url_images:
      response = requests.get(image)
      img = PIL.Image.open(BytesIO(response.content))
      format.append(img)
    print(format)

    try:
        return model2.generate_content(format).text
    except:
        print('exception generate_content')
        return None