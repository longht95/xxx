import json
import os
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

##profile
def find_button_follow_profile(wait):
    try:
        script_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'script[type="application/ld+json"]')))
        data = json.loads(script_element.get_attribute('innerHTML'))
        identifier = data['author']['identifier']
        data_testid = '{}-follow'.format(identifier)
        button_follow = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'div[role="button"][data-testid="{}"]'.format(data_testid))))
        return button_follow
    except Exception as e:
        print('exception find_button_follow_profile')
        print(e)
        return None



def find_input_search(wait):
    try:
        return wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'input[role="combobox"][data-testid="SearchBox_Search_Input"]')))
    except:
        return None
def find_button_search(wait):
    try:
        svg_elements = wait.until(EC.element_to_be_clickable((By.TAG_NAME, 'path')))
        for svg_tag in svg_elements:
            if svg_tag.get_attribute("d") in [os.getenv("PATH_SEARCH_BUTTON")]:
                return svg_tag
    except:
        return None
    return None
def find_home_button(wait):
    try:
        svg_elements = wait.until(EC.presence_of_all_elements_located((By.TAG_NAME, 'path')))
        for svg_tag in svg_elements:
            if svg_tag.get_attribute("d") in [os.getenv("PATH_HOME_BUTTON")]:
                return svg_tag
        #return next((svg for svg in element.find_elements(By.TAG_NAME, 'path') if svg.get_attribute("d") in [os.getenv("PATH_CLOSE_BUTTON"), os.getenv("PATH_BACK_BUTTON")]), None)
    except:
        return None
    return None
#find_in_element
def find_contents(element):
    return [content.text for content in element.find_elements(By.CSS_SELECTOR, 'div[data-testid="tweetText"]')]

def find_images(element):
    try:   
        return [img.get_attribute('src') for img in element.find_elements(By.TAG_NAME, 'img') if img.get_attribute('src').startswith('https://pbs.twimg.com/media/')]
    except:
        return None
    
def find_back_navigation(wait):
    try:
        return wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'div[role="button"][data-testid="app-bar-back"]')))
    except:
        return None
    

    #try:
    #    url = next((e for e in element.find_elements(By.TAG_NAME, "a") if pattern.match(e.get_attribute("href"))), None)
    #except:
       # print('exception find_url_tweet')
        #return None
    #return url.get_attribute("href") if url else None



#New Code
