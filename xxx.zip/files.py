import os
import numpy as np
import pandas as pd

class Profile:
    def __init__(self, name, password, scret_key, proxy, profile_dir, like_rate, comment_rate, view_ads, user_ads, time_process, start, accounts, work):
        self.username = name
        self.password = password
        self.scret_key = scret_key
        self.proxy = proxy
        self.profile_dir = profile_dir
        self.like_rate = float(like_rate)
        self.comment_rate = float(comment_rate)
        self.view_ads = bool(view_ads)
        self.user_ads = user_ads
        self.time_process = int(time_process)
        self.start = bool(start)
        if accounts:
            self.accounts = accounts.split(',')
        else:
            self.accounts = []
        self.work = bool(work)

def read_profile_list_from_file(file_path):
    profiles = []
    ser = pd.read_excel(file_path,sheet_name='Test', header=None, skiprows=1)
    num_rows = len(ser)  # Số hàng trong Series
    for row_index in range(num_rows):
        value = ser.iloc[row_index]
        profile = Profile(*value)
        profiles.append(profile)
    return profiles
    
        
def read_white_account_from_file(file_path):
    white_list = []
    ser = pd.read_excel(file_path,sheet_name='white_list', header=None)
    num_rows = len(ser)  # Số hàng trong Series
    for row_index in range(num_rows):
        value = ser.iloc[row_index]
        white_list.append(value[0])
    return white_list

def read_white_list_from_file(file_path):
    white_account = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                account = line.strip()
                white_account.append(account)
    except FileNotFoundError:
        return white_account
    except Exception as e:
        return white_account
    return white_account

#New code
def read_urls_comment_by_main_account():
    urls = []
    ser = pd.read_excel(os.getenv('PROFILE_PATH'),sheet_name='Url_comment', header=None)
    num_rows = len(ser)
    for row_index in range(num_rows):
        value = ser.iloc[row_index]
        urls.append(value[0])
    return urls