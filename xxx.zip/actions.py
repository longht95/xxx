import os
import random
import re
import time

from AI import generate_comment_by_text_images
from finds import find_back_navigation, find_contents, find_images
from selenium.webdriver.common.by import By

from selenium.webdriver.support import expected_conditions as EC


        




def action_comment(element, action, driver, wait):
    print('comment')
    images = find_images(element)
    contents = find_contents(element)
    content_coment = None
    if (len(images) > 0 or len(contents) > 0):
    
        content_coment = generate_comment_by_text_images(find_contents(element), find_images(element))
    if (content_coment):
        button_comment = element.find_element(By.CSS_SELECTOR, 'div[role="button"][data-testid="reply"]')
        action.move_to_element(button_comment).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click(button_comment).perform()
        time.sleep(random.uniform(1, 5))

        input_text = driver.find_element(By.CSS_SELECTOR, 'div[role="textbox"][data-testid="tweetTextarea_0"]')
        action.move_to_element(input_text).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click(input_text).perform()

        time.sleep(random.uniform(10, 30))
        action.send_keys(content_coment)
        time.sleep(random.uniform(0.5, 2))

        publish = driver.find_element(By.CSS_SELECTOR, 'div[data-testid="tweetButton"][role="button"]')
        action.move_to_element(publish).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click(publish).perform()
        time.sleep(random.uniform(5, 10))

def action_details(wait, action, element):
    print('action_details')
    regex = r"https:\/\/twitter\.com\/\w+\/status\/\d+$"
    pattern = re.compile(regex)
    tweet = next((e for e in element.find_elements(By.TAG_NAME, "a") if pattern.match(e.get_attribute("href"))), None)
    if (tweet):
        action.move_to_element(tweet).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click(tweet).perform()
        time.sleep(random.uniform(10, 30))
        
        closeButton = find_back_navigation(wait)
        action.move_to_element(closeButton).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click().perform()
        time.sleep(random.uniform(5, 10))

