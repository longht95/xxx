import os
import random
import re
import time

from AI import generate_comment_by_image_and_text, generate_comment_by_text, generate_comment_by_text_images, generate_content_by_text
from finds import find_back_navigation, find_contents, find_images
from selenium.webdriver.common.by import By

from selenium.webdriver.support import expected_conditions as EC


def action_details(wait, action, element):
    print('action_details')
    regex = r"https:\/\/twitter\.com\/\w+\/status\/\d+$"
    pattern = re.compile(regex)
    tweet = next((e for e in element.find_elements(By.TAG_NAME, "a") if pattern.match(e.get_attribute("href"))), None)
    if (tweet):
        action.move_to_element(tweet).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click(tweet).perform()
        time.sleep(random.uniform(10, 30))
        
        closeButton = find_back_navigation(wait)
        action.move_to_element(closeButton).perform()
        time.sleep(random.uniform(0.5, 2))
        action.click().perform()
        time.sleep(random.uniform(5, 10))

